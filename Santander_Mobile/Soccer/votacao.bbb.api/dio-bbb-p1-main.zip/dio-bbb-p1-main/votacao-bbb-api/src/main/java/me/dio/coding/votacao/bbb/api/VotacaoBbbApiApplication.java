package me.dio.coding.votacao.bbb.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VotacaoBbbApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(VotacaoBbbApiApplication.class, args);
	}

}
