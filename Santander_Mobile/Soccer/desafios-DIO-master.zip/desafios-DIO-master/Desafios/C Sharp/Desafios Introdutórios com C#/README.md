## BootCamp

- everis New Talents #2 .NET
Olá Dev! Aqui está a oportunidade incrível para você conquistar um espaço na everis. Por meio do Bootcamp everis New Talents #2 .NET, você terá chances de contratação, além de aprender sobre as principais ferramentas de testes mais utilizadas no mercado, conectando-se com grandes experts da área.


