## BootCamp

- Take Blip Fullstack Developer #2
Olá Dev! Aqui está a oportunidade incrível para você se tornar um profissional Fullstack. Com o Bootcamp Take Blip Fullstack Developer #2, você aprenderá o melhor que o C#, a principal linguagem da Microsoft pode oferecer, e criar aplicações completas utilizando React no front-end. O bootcamp Take Blip Fullstack Developer faz parte do programa Órbi Academy Techboost, iniciativa da DIO junto ao Órbi Conecta, que até 2022 distribuirá 130 mil bolsas de estudo gratuitas, fortalecendo ainda mais a comunidade tech brasileira.


