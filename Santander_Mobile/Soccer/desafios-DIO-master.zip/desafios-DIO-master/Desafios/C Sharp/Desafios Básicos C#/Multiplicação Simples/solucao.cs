using System;

class MultiplicacaoSimples  {
    static void Main(string[] args) {

        var valor1 = int.Parse(Console.ReadLine());
        var valor2 = int.Parse(Console.ReadLine());
        
        var total = valor1 * valor2;
        
        Console.WriteLine("PROD = " + total);
    }
}


 