## Desafio

Você receberá dois valores inteiros. Faça a leitura e em seguida calcule o produto entre estes dois valores. Atribua esta operação à variável PROD, mostrando esta de acordo com a mensagem de saída esperada (exemplo abaixo). 

## Entrada

A entrada contém 2 valores inteiros.

## Saída

Exiba a variável PROD conforme exemplo abaixo, tendo obrigatoriamente um espaço em branco antes e depois da igualdade.

| Exemplo de Entrada | Exemplo de Saída|
| ---|--- |
| 3<br />9 | PROD = 27 |
| -303<br />10 | PROD = -300 |
| 0<br />9 | PROD = 0 |
