## BootCamp

- Aceleração Global Dev #21 GFT
Conheça já a Aceleração Global Dev #21 GFT: um programa para aprofundar sua expertise sobre as tecnologias .NET e AWS! No dia 19/02/2022, os experts da GFT vão compartilhar competências técnicas e práticas adotadas pelos times de tecnologia da multinacional através de Workshops exclusivos. A Aceleração Global Dev #21 GFT tem oportunidades de contratação. Sim! A GFT busca profissionais com experiência em .NET, para trabalhar em Home Office por todo o Brasil. Conquiste já a sua vaga! Inscreva-se.

