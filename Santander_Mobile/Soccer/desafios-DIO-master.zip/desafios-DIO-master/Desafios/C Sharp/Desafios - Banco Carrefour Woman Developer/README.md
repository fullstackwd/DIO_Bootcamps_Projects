## BootCamp

- Banco Carrefour Woman Developer
Olá Dev! Já imaginou se tornar ainda mais potente para o mercado se especializando na tecnologia empregada para aplicações de Back-end, muito utilizada no mercado atual? Se a resposta for sim, esta é a sua chance! O Bootcamp Banco Carrefour Woman Developer foi pensado exclusivamente para o seu desenvolvimento em .NET, contendo uma sequência completa de cursos, mentorias e desafios. Não perca essa chance e inscreva-se já!


