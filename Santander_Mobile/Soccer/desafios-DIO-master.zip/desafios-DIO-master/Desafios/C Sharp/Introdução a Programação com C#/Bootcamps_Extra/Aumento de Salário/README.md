## Desafio

A empresa ABC resolveu conceder um aumento de salários a seus funcionários de
acordo com a tabela abaixo:

Leia o salário do funcionário e calcule e mostre o novo salário, bem como o
valor de reajuste ganho e o índice reajustado, em percentual.

## Entrada

A entrada contém apenas um valor de ponto flutuante, que pode ser maior ou
igual a zero, com duas casas decimais.

## Saída

Imprima 3 linhas na saída: o novo salário, o valor ganho de reajuste e o
percentual de reajuste ganho, conforme exemplo abaixo.
