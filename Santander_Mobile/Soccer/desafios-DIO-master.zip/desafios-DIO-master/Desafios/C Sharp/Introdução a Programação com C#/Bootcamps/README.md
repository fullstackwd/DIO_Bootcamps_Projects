## BootCamp

- .Net Fundamentals
Esse bootcamp é para as pessoas que estão iniciando sua carreira em desenvolvimento de software. Você aprenderá a desenvolver projetos em uma das linguagens de back-end mais utilizadas no mundo, o .NET C#, e a resolver algoritmos tendo um aprendizado completo, da teoria à prática.

- Avanade Fullstack Developer
Nesse bootcamp você vai desenvolver projetos usando.NET e Angular, além de aprender os requisitos básicos para conquistar oportunidades na Avanade Brasil, empresa multinacional presente em 25 países.

- everis New Talents - .NET
Bem-vindo ao seu bootcamp com foco em back-end e arquitetura com dotnet C#, aqui você tera a oportunidade para dar seus primeiros passos em dotnet e criar aplicações corporativas.

- Decola Dev Avanade 2021
Decola Dev é uma combinação de jornada de aceleração e programa de estágio onde os talentos poderão fazer parte de um Bootcamp com mais de 80 horas de duração para se prepararem para o processo seletivo de estágio da Avanade, uma empresa global, joint venture da Microsoft e Accenture, que faz a tecnologia acontecer.
