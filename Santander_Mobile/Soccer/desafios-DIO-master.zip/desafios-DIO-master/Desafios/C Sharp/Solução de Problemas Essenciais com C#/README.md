## BootCamp

- Avanade Fullstack Developer
Nesse bootcamp você vai desenvolver projetos usando.NET e Angular, além de aprender os requisitos básicos para conquistar oportunidades na Avanade Brasil, empresa multinacional presente em 25 países.

- Decola Dev Avanade 2021
Decola Dev é uma combinação de jornada de aceleração e programa de estágio onde os talentos poderão fazer parte de um Bootcamp com mais de 80 horas de duração para se prepararem para o processo seletivo de estágio da Avanade, uma empresa global, joint venture da Microsoft e Accenture, que faz a tecnologia acontecer.
