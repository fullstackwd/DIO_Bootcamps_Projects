## BootCamp

- LocalizaLabs .NET Developer
Bem-vindo ao bootcamp #LocalizaLabs! O #LocalizaLabs é o laboratório de tecnologia e inovação da Localiza e conta com quase 700 colaboradores totalmente dedicados à tecnologia e a tudo o que ela nos possibilita na jornada de transformação. Acreditamos que a inovação, na prática, só é possível por meio da troca de compartilhamento de ideias, por isso, essa trilha é formada por conteúdos com experts em diferentes habilidades das skills esperadas no programa de contratação. Aqui você vai aprender e desenvolver competências buscadas no mercado de .NET utilizando C# e ainda pode conquistar uma oportunidade de integrar o time da maior locadora de veículos da América Latina.

- everis New Talents - .NET
Bem-vindo ao seu bootcamp com foco em back-end e arquitetura com dotnet C#, aqui você tera a oportunidade para dar seus primeiros passos em dotnet e criar aplicações corporativas.