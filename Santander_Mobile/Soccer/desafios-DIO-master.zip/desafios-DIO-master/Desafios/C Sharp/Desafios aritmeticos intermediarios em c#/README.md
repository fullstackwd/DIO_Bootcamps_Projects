## BootCamp

- GFT START #2 .NET
Desenvolva seus primeiros passos e primeiros projetos na stack de .net C# com grandes experts de mercado e construa aplicações de alto nível com embasamento técnico de arquitetura em back-end.