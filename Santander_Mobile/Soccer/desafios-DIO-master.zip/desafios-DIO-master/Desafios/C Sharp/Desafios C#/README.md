## BootCamp

- LocalizaLabs .NET Developer #2
Olá Dev, o Bootcamp LocalizaLabs .NET Developer #2, faz parte do programa Órbi Academy Techboost - com uma iniciativa da DIO junto ao Órbi, está pronto para você! Neste Bootcamp você aprenderá os conceitos principais sobre .NET para atuação em projetos de desenvolvimento web e de componentes de interface de usuários. O Órbi Conecta é um dos principais hubs de inovação do Brasil e o Órbi Academy Techboost é um dos maiores programas brasileiros de formação em carreiras de tecnologia que distribuirá mais de 130 mil bolsas de estudo até 2022, impactando toda a comunidade tech brasileira.


