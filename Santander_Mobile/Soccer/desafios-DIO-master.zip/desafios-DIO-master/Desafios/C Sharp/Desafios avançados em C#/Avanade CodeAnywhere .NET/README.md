## BootCamp

- Avanade CodeAnywhere .NET
Desenvolva projetos .NET com C# em conjunto com os melhores experts da Avanade para ampliar o seu conhecimento, criar um portfólio inovador e conquistar grandes oportunidades.

