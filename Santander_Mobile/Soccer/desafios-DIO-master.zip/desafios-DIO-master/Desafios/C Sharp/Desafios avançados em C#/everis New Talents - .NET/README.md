## BootCamp

- everis New Talents - .NET
Bem-vindo ao seu bootcamp com foco em back-end e arquitetura com dotnet C#, aqui você tera a oportunidade para dar seus primeiros passos em dotnet e criar aplicações corporativas.