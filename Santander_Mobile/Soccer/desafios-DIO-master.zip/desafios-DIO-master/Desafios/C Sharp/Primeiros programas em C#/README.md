## BootCamp

- Take Blip Fullstack Developer
Desenvolva soluções fullstack aproveitando o melhor que o C#, a principal linguagem da Microsoft pode oferecer, e crie aplicações completas utilizando React no front-end. Ao final dessa jornada, você será capaz de construir aplicações web modernas e dentro das boas práticas do mercado.